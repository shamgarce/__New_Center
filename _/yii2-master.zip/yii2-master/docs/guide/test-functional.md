Functional Tests
================

> Note: This section is under development.

- http://codeception.com/docs/05-FunctionalTests

Running basic and advanced template functional tests
----------------------------------------------------

Please refer to instructions provided in `apps/advanced/tests/README.md` and `apps/basic/tests/README.md`.