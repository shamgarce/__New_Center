Getting started with Yii2 development
=====================================

See [Git workflow for Yii 2 contributors](git-workflow.md) on how to set up your environment.
